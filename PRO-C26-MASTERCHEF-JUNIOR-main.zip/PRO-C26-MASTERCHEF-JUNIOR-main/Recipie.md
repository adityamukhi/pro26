INSTRUCTIONS

firstly, in a large vessel get 2 litre milk of milk to a boil stirring occasionally.

once the milk comes to a boil, pour 2 tbsp lemon juice and stir well. you can alternatively use curd or vinegar.

stir until the milk curdles keeping the flame on low to medium.

do not boil further once water separates completely.

drain the curdled milk over a cloth-lined over a colander. you can use the leftover water to make soup or knead the dough as they are very nutritious.

squeeze off the water completely. be careful as the curdled milk will be very hot.

rinse off the curdled milk with fresh water to remove sourness from lemon juice.

squeeze off the water completely. do not over squeeze as the moisture in paneer will be lost.

hang for 1 hour making sure the water is drained completely, yet remain the moisture.

after 1 hour, start to mash the paneer for 5 minutes.

mash the paneer till it turns out smooth texture without any grains of paneer.

now prepare small ball sized paneer and keep aside. cover and keep to prevent from drying.

in a large vessel take 1 cup sugar, 5 cup water and 3 pod cardamom.

stir and dissolve the sugar completely.

now boil the water for 5 minutes.

drop in rolled paneer balls one by one into boiling sugar water.

cover and boil for 10 minutes or until rasgulla doubles in size.

now drop into ice-cold water immediately, to prevent from shrinking in size.

once cooled completely, take into a serving bowl and pour in leftover sugar water.

finally, enjoy rasgulla chilled or as it is.
