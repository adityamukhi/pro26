INGREDIENTS - 

▢2 litre milk, full cream

▢2 tbsp lemon juice

▢1 cup sugar

▢5 cup water

▢3 pod cardamom
